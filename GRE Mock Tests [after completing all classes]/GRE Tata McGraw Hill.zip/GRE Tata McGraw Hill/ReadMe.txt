-------------------------------------------------------------------
README
-------------------------------------------------------------------

�2011 Copyright McGraw-Hill Companies. All rights reserved.


SYSTEM REQUIREMENTS
===============================

PC
-----
Microsoft Windows 2000, XP, Vista, 7
Intel Pentium III processor (450 MHz recommended)
128 MB RAM
Display capable of 800 x 600 resolution and 16-bit color
Windows compatible sound card
Approximately 100 MB Hard Disk space 

Apple Macintosh
-------------------------
Mac OS X 10.5.x, 10.6.x
G3 Power PC/ Intel Solo or higher
500 Mhz / 1.0 Ghz or higher in processing speed
256 MB RAM
Display capable of 800 x 600 resolution and 16-bit color
Approximately 200 MB Hard Disk space


INSTRUCTIONS
===============================

1) Insert the CD-ROM into the computer.

2) On a Macintosh, the CD-ROM will display its contents. To launch CD, drag the program icon to the Applications folder;
   On Windows, the CD-ROM should autolaunch. If not, double click the program icon from the "My Computer" window and then double click the Install icon.